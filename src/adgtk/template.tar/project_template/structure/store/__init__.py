"""Data Store
"""
from .simple import SimpleRecordStore
