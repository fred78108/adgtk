"""Prompt generators"""

from .fixed import FixedPromptGenerator
