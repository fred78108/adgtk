from .basic import CsvEnvironment
from .fixed import FixedDictEnvironment

register_list = [CsvEnvironment, FixedDictEnvironment]