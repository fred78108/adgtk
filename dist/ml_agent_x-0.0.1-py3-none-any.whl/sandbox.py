import toml
from scenario import MeasureDatasetScenario, MeasureModelPerformanceScenario
from scenario import factory as scenario_factory
from utils.plugins import load_plugins
from utils.settings import load_settings
import pprint
from scenario import Scenario, MeasureModelPerformanceScenario


def sample_config():
    # just a funky data schema to test toml
    data = {
        "scenario": "one",
        "agent": {"type": "simple", "policy": {"type": "funky", "count": 10}},
    }
    with open("tmp.toml", "w") as outfile:
        toml.dump(data, outfile)

    with open("tmp.toml", "r") as infile:
        data = toml.load("tmp.toml")
        pprint.pp(data)


def config_test():
    data = toml.load("settings.toml")
    pprint.pp(data)


def main() -> None:
    scenario_factory.register("meas-ds", MeasureDatasetScenario)
    scenario_factory.register("model-perf", MeasureModelPerformanceScenario)

    scenario_to_run = scenario_factory.create({"type": "test2"})
    scenario_to_run.execute()


def test_gen_blueprint():

    blueprint = toml.dumps(MeasureModelPerformanceScenario.blueprint)
    print(blueprint)


def test_load_settings():
    data = load_settings()
    pprint.pp(data["data"])


if __name__ == "__main__":
    print("..")
    test_load_settings()
    print("..")
    exit()
    load_plugins()
    active = scenario_factory.active_registrations()
    print(active)
    main()
    config_test()
    sample_config()
    print("AAA")
    pprint.pp(MeasureModelPerformanceScenario.blueprint)
    print("BBB")
    test_gen_blueprint()
