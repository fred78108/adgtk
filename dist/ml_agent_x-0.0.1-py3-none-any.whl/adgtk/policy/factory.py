"""Factory for the Policy

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


from typing import Any, Callable
from common import DuplicateFactoryRegistration
from .base import Policy

# ----------------------------------------------------------------------
# data
# ----------------------------------------------------------------------

policy_creation_functions: dict[str, Callable[..., Policy]] = {}

# ----------------------------------------------------------------------
# Functions
# ----------------------------------------------------------------------


def register(policy_label: str, creator_fn: Callable[..., Policy]) -> None:
    """Register a policy.

    Args:
        policy_label (str): _description_
        creator_fn (Callable[..., Policy]): The Policy to add

    Raises:
        DuplicateFactoryRegistration: Already exists
    """
    if policy_label not in policy_creation_functions:
        policy_creation_functions[policy_label] = creator_fn
    else:
        raise DuplicateFactoryRegistration


def unregister(policy_label: str) -> None:
    """remove a policy from the factory registration

    Args:
        policy_label (str): The policy to remove
    """
    policy_creation_functions.pop(policy_label, None)


def create(arguments: dict[str, Any]) -> Policy:
    """Create a policy based on the arguments

    Args:
        arguments (dict[str, Any]): the configuration

    Raises:
        ValueError: Unknown policy

    Returns:
        Policy: An instance of a Policy
    """
    args_copy = arguments.copy()
    policy_label = args_copy.pop("type")
    try:
        creator_func = policy_creation_functions[policy_label]
    except KeyError:
        raise ValueError(f"unknown policy type {policy_label!r}") from None
    return creator_func(**args_copy)


def active_registrations() -> list:
    """Retrieves a list of the registered Policies

    Returns:
        list: The current list of registered Policies
    """
    return list(policy_creation_functions.keys())
