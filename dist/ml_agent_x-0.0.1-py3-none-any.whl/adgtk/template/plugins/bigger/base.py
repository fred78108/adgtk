class TestScenarioTwo:

    def __init__(self):
        print("Created a TestScenario2")

    def execute(self) -> None:
        """ "Execute actions based on Agent type (interacting with evn,
        expanding data, etc).
        """
        print("execute - test scenario2")

    def preview(self) -> None:
        """Builds a preview of the Agent."""
        print("preview - test scenario2")
