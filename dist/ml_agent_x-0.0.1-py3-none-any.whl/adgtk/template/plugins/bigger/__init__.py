from .base import TestScenarioTwo
from scenario import scenario_factory

scenario_factory.register("test2", TestScenarioTwo)
