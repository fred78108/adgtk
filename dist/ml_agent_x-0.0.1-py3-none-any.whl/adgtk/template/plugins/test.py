import scenario.factory as scenario_factory


class TestScenario:

    def __init__(self):
        print("Created a TestScenario")

    def execute(self) -> None:
        """ "Execute actions based on Agent type (interacting with env,
        expanding data, etc).
        """
        print("execute - test scenario")

    def preview(self) -> None:
        """Builds a preview of the Agent."""
        print("preview - test scenario")


# and register!
scenario_factory.register("test-scenario", TestScenario)
