"""The contents to be expanded when creating a project

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0

Test
python -m unittest tests.
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


# ----------------------------------------------------------------------
# Module configuration
# ----------------------------------------------------------------------

# ----------------------------------------------------------------------
# Folders to create
# ----------------------------------------------------------------------
folders_w_init = ["plugins"]
folders_no_init = ["data"]

# ----------------------------------------------------------------------
# files with content
# ----------------------------------------------------------------------
root_source_content = {
    "README.md": """# {PROJECT_NAME}

## Description

## Goals

## Plugins created
""",
    "settings.toml": """[data]
data_dir = "data"

[tensorboard]
tb_dir = "runs"
start_tb = false

[available]
agent = ["BasicAgent"]
policy = ["RandomPolicy"]

[defaults]
agent = "BasicAgent"
policy = "RandomPolicy"
""",
}
