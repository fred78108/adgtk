"""Creates a project for the user

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0 Get "fancier" on is_valid_folder_name

Defects:

1.0

Test
python -m unittest tests.
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

import os
import sys
from pathlib import Path
from .project_content import (
    folders_w_init,
    folders_no_init,
    root_source_content
)

# ----------------------------------------------------------------------
# Module configuration
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
#
# ----------------------------------------------------------------------


def is_valid_folder_name(folder_name: str) -> bool:
    """Validates a folder

    Args:
        folder_name (str): The folder name to test

    Returns:
        bool: T: valid for our use, F: Not valid
    """
    if " " in folder_name:
        return False
    if "*" in folder_name:
        return False
    if len(folder_name) == 0:
        return False

    return True


def create_project(project_name: str) -> None:
    """Creates a project with all the supporting folders

    Args:
        project_name (str): The folder to create
    """
    if not is_valid_folder_name:
        print("Not bad eh?")
        raise ValueError()
    else:
        print("huh?")

    # first create the main project
    try:
        os.makedirs(project_name, exist_ok=False)
    except FileExistsError:
        print(f"{project_name} already exists. Exiting")
        sys.exit()

    for folder in folders_no_init:
        folder_w_path = os.path.join(project_name, folder)
        os.makedirs(folder_w_path, exist_ok=True)

    for folder in folders_w_init:
        folder_w_path = os.path.join(project_name, folder)
        os.makedirs(folder_w_path, exist_ok=True)
        init_w_path = os.path.join(folder_w_path, "__init__.py")
        Path.touch(init_w_path)

    for filename, content in root_source_content.items():
        content = content.replace("{PROJECT_NAME}", project_name)
        file_w_path = os.path.join(project_name, filename)
        with open(file_w_path, "w", encoding="utf-8") as outfile:
            outfile.write(content)
