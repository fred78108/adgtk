"""Factory for the scenario

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


from typing import Any, Callable
from factory import DuplicateFactoryRegistration
from .base import Scenario

# ----------------------------------------------------------------------
# data
# ----------------------------------------------------------------------

scenario_creation_functions: dict[str, Callable[..., Scenario]] = {}

# ----------------------------------------------------------------------
# Functions
# ----------------------------------------------------------------------


def register(scenario_label: str, creator_fn: Callable[..., Scenario]) -> None:
    """Register a scenario.

    Args:
        scenario_label (str): _description_
        creator_fn (Callable[..., Scenario]): The Scenario to add

    Raises:
        DuplicateFactoryRegistration: Already exists
    """
    if scenario_label not in scenario_creation_functions:
        scenario_creation_functions[scenario_label] = creator_fn
    else:
        raise DuplicateFactoryRegistration


def unregister(scenario_label: str) -> None:
    """remove a scenario from the factory registration

    Args:
        scenario_label (str): The scenario to remove
    """
    scenario_creation_functions.pop(scenario_label, None)


def create(arguments: dict[str, Any]) -> Scenario:
    """Create a scenario based on the arguments

    Args:
        arguments (dict[str, Any]): _description_

    Raises:
        ValueError: Unknown scenario

    Returns:
        ScenarioDefinition: The scenario
    """
    args_copy = arguments.copy()
    scenario_label = args_copy.pop("type")
    try:
        creator_func = scenario_creation_functions[scenario_label]
    except KeyError:
        raise ValueError(f"unknown scenario type {scenario_label!r}") from None
    return creator_func(**args_copy)


def active_registrations() -> list:
    """Retrieves a list of the registered Scenarios

    Returns:
        list: The current list of registered Scenarios
    """
    return list(scenario_creation_functions.keys())
