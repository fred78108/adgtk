"""Scenario base

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


from typing import Protocol, Literal
import logging
from dataclasses import dataclass
from abc import ABC, abstractmethod

# from constants.literals import SCENARIO_CREATE_LITERAL
# from journals.experiment import ExperimentJournal
# from presentation.foundation import PresentationFormatConfig
# from common.exceptions import InvalidConfigException


class Scenario(Protocol):
    """The Scenario Protocol"""

    blueprint: dict

    def execute(self) -> None:
        """ "Execute actions based on Agent type (interacting with evn,
        expanding data, etc).
        """

    def preview(self) -> None:
        """Builds a preview of the Agent."""
