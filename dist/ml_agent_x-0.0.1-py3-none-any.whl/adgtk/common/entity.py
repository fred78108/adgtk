"""Included Measurement scenarios

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# TODO: this should not be part of the initial package!! move to project
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

from dataclasses import dataclass


@dataclass
class Entity:
    data: dict
    string_rep: str
    schema: str = "entity"


@dataclass
class EntityPairState:
    left: Entity
    right: Entity
    label: int
    schema: str = "entity-pair"
