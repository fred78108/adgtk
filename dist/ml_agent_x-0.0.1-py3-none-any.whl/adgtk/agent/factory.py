"""Factory for the Agent

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


from typing import Any, Callable
from common import DuplicateFactoryRegistration
from .base import Agent

# ----------------------------------------------------------------------
# data
# ----------------------------------------------------------------------

agent_creation_functions: dict[str, Callable[..., Agent]] = {}

# ----------------------------------------------------------------------
# Functions
# ----------------------------------------------------------------------


def register(agent_label: str, creator_fn: Callable[..., Agent]) -> None:
    """Register a Agent.

    Args:
        agent_label (str): The identifier of the agent to register
        creator_fn (Callable[..., Agent]): The Agent to add

    Raises:
        DuplicateFactoryRegistration: Already exists
    """
    if agent_label not in agent_creation_functions:
        agent_creation_functions[agent_label] = creator_fn
    else:
        raise DuplicateFactoryRegistration


def unregister(agent_label: str) -> None:
    """remove a Agent from the factory registration

    Args:
        agent_label (str): The Agent to remove
    """
    agent_creation_functions.pop(agent_label, None)


def create(arguments: dict[str, Any]) -> Agent:
    """Create an Agent based on the arguments

    Args:
        arguments (dict[str, Any]): The configuration

    Raises:
        ValueError: Unknown Agent

    Returns:
        AgentDefinition: The Agent
    """
    args_copy = arguments.copy()
    agent_label = args_copy.pop("type")
    try:
        creator_func = agent_creation_functions[agent_label]
    except KeyError:
        raise ValueError(f"unknown agent type {agent_label!r}") from None
    return creator_func(**args_copy)


def active_registrations() -> list:
    """Retrieves a list of the registered Agents

    Returns:
        list: The current list of registered Agents
    """
    return list(agent_creation_functions.keys())
