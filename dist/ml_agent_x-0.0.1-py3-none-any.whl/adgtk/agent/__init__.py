"""Summary goes here.

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0

Test
python -m unittest tests.
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


import logging


# ----------------------------------------------------------------------
# Module configuration
# ----------------------------------------------------------------------
import agent.factory as agent_factory
from .base import Agent
from .simple import BasicAgent

# ----------------------------------------------------------------------
# built-in Agents
# ----------------------------------------------------------------------
agent_factory.register("basic-agent", BasicAgent)
