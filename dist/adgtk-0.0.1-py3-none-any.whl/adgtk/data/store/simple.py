from __future__ import annotations
"""Simple Record Stores
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


import random
from typing import Iterable, List, Union, Any
from adgtk.data.records import PresentableRecord

# ----------------------------------------------------------------------
#
# ----------------------------------------------------------------------
# py -m pytest -s test/folder/.py


class SimpleRecordStore:
    """More a proof of concept Store. Useful for demonstration as well
    as supporting testing.
    """

    def __init__(self):
        self._records: List[PresentableRecord] = []
        self.idx = 0            # for iteration

    def __len__(self) -> int:
        """The number of the records in the store

        :return: The count of records
        :rtype: int
        """
        return len(self._records)

    def __iter__(self) -> SimpleRecordStore:
        """Return self

        :return: return self
        :rtype: SupportRecordStore
        """
        return self

    def __next__(self) -> PresentableRecord:
        """gets next record for an interation
        """
        if self.idx < len(self._records):
            self.idx += 1
            return self._records[(self.idx-1)]
        else:
            # reset for the next time we iterate
            self.idx = 0
            raise StopIteration

    def __getitem__(self, index: int) -> PresentableRecord:
        """Returns an item at index

        :param index: _description_
        :type index: _type_
        :return: _description_
        :rtype: PresentableRecord
        """
        return self._records[index]

    def insert(self, record: PresentableRecord) -> None:
        """Insert a single record

        :param record: _description_
        :type record: Any
        """
        self._records.append(record)

    def bulk_insert(self, records: Iterable[PresentableRecord]) -> None:
        """insert several records at once

        :param records: _description_
        :type records: Iterable[PresentableRecord]
        """
        pass

    def shuffle(self) -> None:
        """Shuffles the order of records.
        """
        random.shuffle(self._records)

    def export_to_dict(self) -> dict:
        """_summary_

        :return: _description_
        :rtype: dict
        """
        return {}

    def import_from_dict(
        self,
        data: dict,
        metadata: Union[dict[str, Any], None] = None
    ) -> bool:
        """_summary_

        :param data: _description_
        :type data: dict
        :param metadata: _description_, defaults to None
        :type metadata: dict, optional
        :return: _description_
        :rtype: bool
        """
        return False

    def rebuild_from_disk(self, filename: str) -> bool:
        """_summary_

        :param filename: _description_
        :type filename: str
        :return: _description_
        :rtype: bool
        """
        return False

    def save_to_disk(self, filename: str) -> None:
        """_summary_

        :param filename: _description_
        :type filename: str
        """
        pass

    def get_all_records(self, copy: bool = False) -> list:
        """_summary_

        :param copy: _description_, defaults to False
        :type copy: bool, optional
        :return: _description_
        :rtype: list
        """
        return []
