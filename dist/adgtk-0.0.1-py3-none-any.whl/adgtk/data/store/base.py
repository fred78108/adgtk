from __future__ import annotations
"""Data Stores
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


from typing import Protocol, Union, Callable, TypeVar, Any, Iterable
from adgtk.factory import PresentationFormat
from adgtk.data.records import PresentableRecord
# ----------------------------------------------------------------------
#
# ----------------------------------------------------------------------
# py -m pytest -s test/folder/.py


# ----------------------------------------------------------------------
# Types and Protocols
# ----------------------------------------------------------------------

T = TypeVar("T", bound=Callable, covariant=True)


class SupportsRecordStore(Protocol):

    def __len__(self) -> int:
        """_summary_

        :return: _description_
        :rtype: int
        """

    def __iter__(self) -> Any:
        """Return self

        :return: return self
        :rtype: Any
        """

    def __next__(self) -> Any:
        """gets next record for an interation
        """

    def __getitem__(self, index: int) -> Any:
        """Returns an item at index

        :param index: _description_
        :type index: _type_
        :return: _description_
        :rtype: Any
        """

    def insert(self, record: Any) -> None:
        """Insert a single record

        :param record: _description_
        :type record: Any
        """

    def bulk_insert(self, records: Iterable[Any]) -> None:
        """insert several records at once

        :param records: _description_
        :type records: Iterable[Any]
        """

    def shuffle(self) -> None:
        """Shuffles the order of records.
        """

    def export_to_dict(self) -> dict:
        """_summary_

        :return: _description_
        :rtype: dict
        """

    def import_from_dict(
        self,
        data: dict,
        metadata: Union[dict[str, Any], None] = None
    ) -> bool:
        """_summary_

        :param data: _description_
        :type data: dict
        :param metadata: _description_, defaults to None
        :type metadata: dict, optional
        :return: _description_
        :rtype: bool
        """

    def rebuild_from_disk(self, filename: str) -> bool:
        """_summary_

        :param filename: _description_
        :type filename: str
        :return: _description_
        :rtype: bool
        """

    def save_to_disk(self, filename: str) -> None:
        """_summary_

        :param filename: _description_
        :type filename: str
        """

    def get_all_records(self, copy: bool = False) -> list:
        """_summary_

        :param copy: _description_, defaults to False
        :type copy: bool, optional
        :return: _description_
        :rtype: list
        """
