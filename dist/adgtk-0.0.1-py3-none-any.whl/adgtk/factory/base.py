"""The Factory is a Dynamic Factory that is easy to extend object types.
The factory is a shared common resource. By having a flexible factory it
is easier to extend to new objects on behalf of the user without needing
the user to create their own factory and register that factory.

Versions:
v 0.1
- mvp

References:
- https://docs.python.org/3/library/typing.html#typing.TypedDict

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

import logging
from typing import Union, Protocol, Dict, Any
from abc import ABC, abstractmethod
from adgtk.journals import ExperimentJournal
# from dataclasses import dataclass


class DuplicateFactoryRegistration(Exception):
    """Used for registration collision"""

    default_msg = "Registration exists. Unregister first."

    def __init__(self, message: str = default_msg):
        super().__init__(message)


class InvalidBlueprint(Exception):
    """Used when a blueprint is invalid. Covers both a FactoryBlueprint
    as well as any future blueprints."""

    default_msg = "Invalid Blueprint."

    def __init__(self, message: str = default_msg):
        super().__init__(message)
