"""Testing the blueprint factory

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0 Consider moving to the factory module?

Defects:

1.0

Test
py -m pytest -s
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

import logging
from typing import TypedDict, Required, Any, Union
from adgtk.journals import ExperimentJournal
from .base import DuplicateFactoryRegistration
# ----------------------------------------------------------------------
# Blueprint keywords
# ----------------------------------------------------------------------
EXPAND_USING_DEFAULT = "EXPAND"


# ----------------------------------------------------------------------
# Types and Protocols
# ----------------------------------------------------------------------
# T = TypeVar("T", bound=dict, covariant=True)

# class _BlueprintProtocol(Protocol[T]):
#    group_label: str
#    type_label: str


class FactoryBlueprint(TypedDict):
    """A Blueprint is used to create a template for an experiment."""
    group_label: Required[str]
    type_label: Required[str]
    arguments: Required[dict[str, Any]]
# ----------------------------------------------------------------------
# Factory
# ----------------------------------------------------------------------


class BlueprintFactory:
    """A factory dedicated to blueprints"""

    def __init__(
        self,
        journal: Union[ExperimentJournal, None] = None,
        blueprint_dir: str = "blueprints",
        ** kwargs
    ) -> None:
        super().__init__()
        self.default_blueprint: dict[str, FactoryBlueprint] = {}
        self._journal = journal
        self._registry: dict[str, dict[str, FactoryBlueprint]] = {}
        self.blueprint_dir = blueprint_dir

    def register(
        self,
        group_label: str,
        type_label: str,
        blueprint: FactoryBlueprint,
        set_default_blueprint: bool = False
    ) -> None:
        if group_label not in self._registry:
            self._registry[group_label] = {}

        group = self._registry[group_label]
        if type_label in group:
            raise DuplicateFactoryRegistration

        group[type_label] = blueprint

        if set_default_blueprint:
            self.default_blueprint[group_label] = blueprint

        # Blueprint folder management

    def unregister(self, group_label: str, type_label: str) -> None:
        """Unregisters a type from a group

        Args:
            group_label (str): The group to which it belongs
            type_label (str): the type within that group

        Raises:
            KeyError: Group label not found
        """
        if group_label in self._registry:
            group = self._registry[group_label]
            if type_label in group:
                group.pop(type_label, None)

            # now check default
            if group_label in self.default_blueprint:
                group_default = self.default_blueprint[group_label]

                if group_default["group_label"] == type_label:
                    logging.warning(
                        f"unregistered the default for {group_label}")
                    self.default_blueprint.pop(group_label)
        else:
            raise KeyError("Group label not found")

    def create(self, group_label: str, type_label: str) -> FactoryBlueprint:
        if group_label not in self._registry:
            # return an empty
            return {
                "group_label": "",
                "type_label": "",
                "arguments": {}
            }

        # get the group
        group_blueprints = self._registry[group_label]

        # now work on the type
        if type_label == EXPAND_USING_DEFAULT:
            default_entry = self.default_blueprint[group_label]
        elif type_label in group_blueprints:
            default_entry = group_blueprints[type_label]
        else:
            # return an empty
            return {
                "group_label": group_label,
                "type_label": "",
                "arguments": {}
            }

        if default_entry is None:
            # should not happen but coding just in case
            return {
                "group_label": group_label,
                "type_label": "",
                "arguments": {}
            }

        # made it through the safety checks. building blueprint
        new_blueprint = default_entry.copy()
        comp_args = new_blueprint["arguments"]
        new_args: dict[str, Any] = {}
        for key, value in comp_args.items():
            if isinstance(value, dict):
                if "group_label" in value and "type_label" in value:
                    # new_blueprint["arguments"][key] = self.create(**value)
                    new_args[key] = self.create(
                        group_label=value["group_label"],
                        type_label=value["type_label"]
                    )
                else:
                    new_args[key] = value
            else:
                new_args[key] = value

        new_blueprint["arguments"] = new_args
        return new_blueprint

    def registry_listing(self, group_label: Union[str, None] = None) -> list:
        """Returns a list of either a group of the entire registry

        Args:
            group_label (str, optional): the group to list, None for all.
                Defaults to None.

        Raises:
            KeyError: the group label not found

        Returns:
            list: a list of the labels
        """
        if group_label is None:
            return list(self._registry.keys())
        else:
            try:
                group = self._registry[group_label]
                return list(group.keys())
            except KeyError as e:
                raise KeyError("Invalid group_label") from e
