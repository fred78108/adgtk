from __future__ import annotations
"""Summary goes here.

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0 Consider moving to the factory module?

Defects:

1.0

Test
py -m pytest -s test/factory/test_component_factory.py
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

import logging
from typing import Any, Union, Protocol, Callable, TypeVar, runtime_checkable
from adgtk.journals import ExperimentJournal
from .base import DuplicateFactoryRegistration
from .blueprint import FactoryBlueprint


# ----------------------------------------------------------------------
# Types and Protocols
# ----------------------------------------------------------------------

# can be sub'd for more specific
T = TypeVar("T", bound=Callable, covariant=True)


@runtime_checkable
class SupportsBlueprint(Protocol):
    blueprint: FactoryBlueprint

    __call__: Callable[..., T]


@runtime_checkable
class PresentationFormat(Protocol):
    """Provides a base for a presentation """

    blueprint: FactoryBlueprint

    __call__: Callable[..., T]

    def present(self, data: dict) -> str:
        """Presents data based on its configuration

        :param data: the data to be presented
        :type data: dict
        :return: a string in the format configured
        :rtype: str
        """


@runtime_checkable
class RequiresAllFactoryEntry(Protocol):
    """Provides a base for any compnent the factory will build
    """

    blueprint: FactoryBlueprint     # must contain a blueprint

    __call__: Callable[..., T]

    def __init__(self, factory: ObjectFactory, journal: ExperimentJournal):
        """_summary_

        :param factory: The factory if needed for init
        :type factory: ObjectFactory
        :param journal: The centralized journal for recording 
            measurements or comments.
        :type journal: ExperimentJournal
        :raises DuplicateFactoryRegistration: Entry already exists        
        """
# ----------------------------------------------------------------------
# Factory
# ----------------------------------------------------------------------


class ObjectFactory:
    """A dynamic factory that creates and manages groups and types"""

    def __init__(
        self,
        journal: Union[ExperimentJournal, None] = None,
        ** kwargs
    ) -> None:

        if journal is None:
            logging.warning("Using default journal.")
            self.journal = ExperimentJournal()

        self._journal: Union[ExperimentJournal, None] = None
        self._registry: dict[str, dict[str, RequiresAllFactoryEntry]] = {}

    def register(
        self,
        group_label: str,
        type_label: str,
        creator: SupportsBlueprint
    ) -> None:
        """Register an object.

        Args:
            group_label (str): The group to which it belongs
            type_label (str): the type within that group
            creator (SupportsBlueprint): The class to create

        Raises:
            DuplicateFactoryRegistration: The type label exists
        """
        if group_label not in self._registry:
            self._registry[group_label] = {}

        group = self._registry[group_label]
        if type_label in group:
            raise DuplicateFactoryRegistration
        group[type_label] = creator

    def unregister(self, group_label: str, type_label: str) -> None:
        """Unregisters a type from a group

        Args:
            group_label (str): The group to which it belongs
            type_label (str): the type within that group

        Raises:
            KeyError: Group label not found
        """
        if group_label in self._registry:
            group = self._registry[group_label]
            if type_label in group:
                group.pop(type_label, None)
        else:
            raise KeyError("Group label not found")

    def create(self, blueprint: FactoryBlueprint) -> Any:
        try:
            group = self._registry[blueprint["group_label"]]
            component_create = group[blueprint["type_label"]]
        except KeyError as e:
            raise KeyError("invalid group_label and type_label") from e

        if isinstance(component_create, RequiresAllFactoryEntry):
            return component_create(
                factory=self,
                journal=self._journal,
                **blueprint["arguments"])
        elif isinstance(component_create, PresentationFormat):
            return component_create(**blueprint["arguments"])
        else:
            return component_create(**blueprint["arguments"])

    def registry_listing(self, group_label: Union[str, None] = None) -> list:
        """Returns a list of either a group of the entire registry

        Args:
            group_label (str, optional): the group to list, None for all.
                Defaults to None.

        Raises:
            KeyError: the group label not found

        Returns:
            list: a list of the labels
        """
        if group_label is None:
            return list(self._registry.keys())
        else:
            try:
                group = self._registry[group_label]
                return list(group.keys())
            except KeyError as e:
                raise KeyError("Invalid group_label") from e
