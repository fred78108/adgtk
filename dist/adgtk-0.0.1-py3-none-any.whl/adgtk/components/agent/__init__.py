"""The Agent module is focused on providing a consistent design for the
Agents within a given project.
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


import logging


# ----------------------------------------------------------------------
# Module configuration
# ----------------------------------------------------------------------
from .base import Agent, BaseAgent
from .simple import BasicAgent
