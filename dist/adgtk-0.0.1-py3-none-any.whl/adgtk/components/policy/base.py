"""Scenario base

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


from typing import Protocol
from adgtk.factory import FactoryBlueprint
from adgtk.components import Action, State


class Policy(Protocol):
    """The Policy Protocol"""

    blueprint: FactoryBlueprint

    def reset(self) -> None:
        """Resets internal state during training."""

    def invoke(self, state: State) -> Action:
        """Invoke the policy to include tracking for training. The
        policy can chose to explore or exploit in response to the ask.

        Args:
            state (State): The state

        Returns:
            Action: The action to take
        """

    def sample(self, state: State) -> Action:
        """Invokes the policy but does not update for training. It only
        seeks to exploit.

        Args:
            state (State): The state

        Returns:
            Action: The action to take
        """

    def update(self, reward: float) -> None:
        """Updates a policy using the reward from the environment for
        the last action.

        Args:
            reward (float): The reward from the last action

        Raises:
            NotImplementedError: Ensures added by a child class
        """

    def refresh(self) -> None:
        """Refreshes the policy by creating training data based on the
        last epoch. This will be used when there is a model to train.
        If there is nothing to update "refresh" then this is a no-op.
        """

# ---------------------------------------------------------------------
# base Policy that can be used for inheritence, testing, etc
# ---------------------------------------------------------------------


class BasePolicy:
    """The Base Policy for testing and inheritence"""

    blueprint: FactoryBlueprint = {
        "group_label": "policy",
        "type_label": "base",
        "arguments": {}
    }

    def reset(self) -> None:
        """Resets internal state during training."""

    def invoke(self, state: State) -> Action:
        """Invoke the policy to include tracking for training. The
        policy can chose to explore or exploit in response to the ask.

        Args:
            state (State): The state

        Returns:
            Action: The action to take
        """

    def sample(self, state: State) -> Action:
        """Invokes the policy but does not update for training. It only
        seeks to exploit.

        Args:
            state (State): The state

        Returns:
            Action: The action to take
        """

    def update(self, reward: float) -> None:
        """Updates a policy using the reward from the environment for
        the last action.

        Args:
            reward (float): The reward from the last action

        Raises:
            NotImplementedError: Ensures added by a child class
        """

    def refresh(self) -> None:
        """Refreshes the policy by creating training data based on the
        last epoch. This will be used when there is a model to train.
        If there is nothing to update "refresh" then this is a no-op.
        """
