"""Handlers for the CLI tools for this project

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0

Test
python -m unittest tests.
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

from typing import Literal
import argparse
import sys
import os
import shutil
import tarfile
import importlib.resources
import toml
import yaml
from jinja2 import Environment, FileSystemLoader
from adgtk.creators.agent import create_agent_plugin
# import adgtk.plugins
# from adgtk.loader.plugin import iter_namespace
from adgtk.scenario import ScenarioManager
import adgtk.creators.defaults as defaults
# ----------------------------------------------------------------------
# Module configuration
# ----------------------------------------------------------------------
WIZARD_OPTIONS = ("agent", "environment", "policy", "scenario", "custom")

# ----------------------------------------------------------------------
# Management
# ----------------------------------------------------------------------


def parse_args() -> argparse.Namespace:
    """Parses the command line arguments

    Returns:
        argparse.Namespace: The command line input
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--create", help="The project to create")
    parser.add_argument("-p", "--plugin", help="Initiate the plugin wizard")
    parser.add_argument("-d", "--destroy", help="The project to destroy")
    parser.add_argument("-r", "--run", help="The experiment to run")
    parser.add_argument(
        "-v",
        "--version",
        help="What is the current version of the script",
        action="store_true",
    )

    args = parser.parse_args()
    return args


def create_settings_file(
    project_name: str,
    format: Literal["toml", "yaml"] = "toml"
) -> None:
    """Creates the default settings.py

    Args:
        project_name (str): The project name
        format (str["toml", "yaml"]): the settings format
    """

    filename = "settings.toml"
    if format == "toml":
        options = toml.dumps(defaults.project_defaults)
    elif format == "yaml":
        filename = "settings.yaml"
        raise NotImplementedError("TOML ONLY FOR NOW!")
        print("TODO!! write YAML file")
        # options = yaml.dumps()

    # now craft the file
    env = Environment(loader=FileSystemLoader(
        os.path.join(project_name, 'templates')))
    template = env.get_template("settings.jinja")
    output = template.render(version=__version__, options=options)

    target_file = os.path.join(project_name, filename)
    with open(file=target_file, encoding="utf-8", mode="w") as outfile:
        outfile.write(output)


def old_create_settings_file(project_name: str) -> None:
    """Creates the default settings.py

    Args:
        project_name (str): The project name
    """
    env = Environment(loader=FileSystemLoader(
        os.path.join(project_name, 'templates')))
    template = env.get_template("settings.jinja")
    output = template.render(version=__version__)

    target_file = os.path.join(project_name, "settings.py")
    with open(file=target_file, encoding="utf-8", mode="w") as outfile:
        outfile.write(output)


def create_project(name: str) -> bool:
    """Creates a project with the basic information needed.

    Args:
        name (str): The project/directory name to create

    Returns:
        bool: True if successful, else False
    """
    if name is None:
        return False

    if os.path.exists(name):
        print("Unable to create a project. remove the other first!")
    elif name is None:
        print("Please specify a name of your project")
    else:
        print(f"Attempting to create {name}")
        filestream = importlib.resources.files(
            "adgtk").joinpath("template.tar").open("rb")

        archive = tarfile.open(fileobj=filestream)
        archive.extractall("./")
        archive.close()

        # and rename
        os.rename("template", name)

        # safety check
        if os.path.exists(name):
            # now create the settings.py
            create_settings_file(name)
            # and let the user know it worked
            print(f"Successfully created project {name}")
            return True

    print(f"Error creating {name}")
    return False


def destroy_project(name: str) -> bool:
    """Destroys a folder and all its contents

    Args:
        name (str): The folder to destroy
    """
    if name is not None:
        if os.path.exists(name):
            confirmation = input(
                f"Please type [{name}] to confirm: ")
            if confirmation.lower() == name.lower():
                shutil.rmtree(name)
                if os.path.exists(name):
                    print("Failed to remove. Please check case")
                else:
                    print(f"Successfully destroyed {name}")
            else:
                print("No action taken.")
            return True
        else:
            print(f"Unable to find project {name} to destroy")
            return True

    return False


def execute(experiment: str) -> None:
    """Runs an experiment

    Args:
        experiment (str): The experiment-definition to run. This is the
            file located in the definition folder as outlined in the
            settings.py file.
    """
    print("TESTING!")
    loader = ScenarioManager(experiment)


def manager() -> None:
    """provides a CLI management"""
    title_string = f"ADGTK - Version {__version__}"
    line_list = ["="] * len(title_string)
    line = "".join(line_list)
    print(line)
    print(title_string)
    print(line)
    print()

    args = parse_args()

    if args.version:
        print(f"{sys.argv[0]}   version {__version__}")

        sys.exit()
    if "destroy" in args and args.destroy is not None:
        if not destroy_project(args.destroy):
            print("Error processing\n")
        else:
            sys.exit()
    elif "create" in args and args.create is not None:
        if not create_project(args.create):
            print("Error processing\n")
        else:
            sys.exit()
    elif "run" in args and args.run is not None:
        execute(args.run)
    else:
        print("WARNING: No option specified.")
        print("Please see --help for more information\n")

    # for entry in importlib.resources.files('adgtk').iterdir():
    #    print(entry.name)
    # tar attempt

# ----------------------------------------------------------------------
# Plugin wizard
# ----------------------------------------------------------------------


def plugin_creator() -> None:
    """Used for creating a plugin. Can be called directly or via the manager"""
    title_string = f"The ML-Agent-X Plugin Wizard Version {__version__}"
    line_list = ["="] * len(title_string)
    line = "".join(line_list)
    print(line)
    print(title_string)
    print(line)
    print()
    input_msg = "Please specify the type of plugin you would like to create? \n" \
                f"Valid options are {WIZARD_OPTIONS}: "
    option = input(input_msg).lower()

    if option == "agent":
        create_agent_plugin()


if __name__ == '__main__':
    manager()
