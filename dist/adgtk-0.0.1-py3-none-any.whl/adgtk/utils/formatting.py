"""
Used for dealing with formatting and parsing of strings.

Versions:
v 0.1
- mvp
v 0.1.1
- added convert_json_values_to_string
v 0.2
- moved constant (prompts) to a separete file
- introduced functions/classes to support two record comparisons.
v 0.2.1
- added logging to SSG to aide in TS slow generation.
v 0.3
- merged and cleaned up SeperateSentenceGenerator
v 0.3.1
- consolidated and refactored cleanups
- added can_further_process
- added cleanup_for_measure
v 0.3.2
- improved logic for yaml_string_to_dict 
v 0.3.3
- added get_json_examples

References:
-

TODO:

1.0 write unittest for get_all_simple_json_from_string
2.0 write unittest for get_name_descr_json_from_chat_history
3.0 write unittest for prefix_dict
4.0 write unittest for merge_dict
5.0 write unittest for convert_json_values_to_string
6.0 cleanup and organize this file with better comments.
7.0 write unittest for the new cleanup and class for two records
8.0 If V2 demonstrates better performance then retire/consolidate
9.0 improve the build_dataset using def _methods instead of one method.
10.0 Retire SeperateSentenceGenerator ? see EntityGenerator classes
11.0 consider ordering keys when creating an output. Does it help the
     model?
12.0 consider expanding get_date_time to include "12 Jan 24" formats

Defects:

1.0

Test
python -m unittest tests.test_utils_formatting
"""


__version__ = "0.3.3"
__author__ = "Fred Diehl"


import datetime
import json
from typing import Union, List
import logging
import numbers
import yaml
import regex as re

# ----------------------------------------------------------------------
# Module Configurations
# ----------------------------------------------------------------------
DEBUG = False

# ----------------------------------------------------------------------
# Common data representations
# ----------------------------------------------------------------------


def get_timestamp_now(include_time: bool = True) -> str:
    """Generates a string with a timestamp. The goal is to have a
    consistent data and date/time format across the different reports,
    etc.

    Args:
        include_time (bool, optional): Include time?.
            Defaults to True.

    Returns:
        str: A timestamp string formatted for reports, etc.
    """
    now = datetime.datetime.now()
    if include_time:
        return now.strftime("%d/%m/%y at %H:%M:%S")
    else:
        return now.strftime("%d/%m/%y")

# ---------------------------------------------------------------------
# YAML
# ---------------------------------------------------------------------


def yaml_string_to_dict(text: str) -> Union[dict, None]:
    """Attempts to convert a YAML string into a dict.

    Args:
        text (str): The candidate YAML string

    Returns:
        Union[dict, None]: Dict if successful, else None
    """
    try:
        data = yaml.safe_load(text)
        if isinstance(data, dict):
            return data
        else:
            return None
    except Exception as e:  # NOQA
        # reminder, we want to be as open as possible for Exceptions
        if DEBUG:
            print(f"yaml_string_to_dict error: {e}")
    return None


def dict_to_yaml_string(data: dict) -> str:
    """Converts a dict to a YAML string

    Args:
        data (dict): The data

    Returns:
        str: String representation in YAML of the data
    """
    try:
        converted = yaml.dump(data)
        return converted
    except Exception as e:  # NOQA
        msg = f"unable to convert data: {data} \n\n: {e} :\n"
        print(msg)
        logging.error(msg)
        return f"ERROR: {e}"


def cleanup_yaml_string(text: str) -> str:
    """Cleans up a YAML string"""
    lines = text.split("\n")
    buffer = []
    for idx, line in enumerate(lines):
        if ":" in line:
            line = line.rstrip()
            if line.startswith(":"):
                # should never start with :
                pass
            elif not ":" == line[-1]:
                # the : is mid-string.
                buffer.append(line)
            elif idx < len(lines):
                try:
                    next_line = lines[idx+1]
                    if next_line.startswith(" ") and ":" in next_line:
                        buffer.append(line)
                except IndexError:
                    # so we can improve later. Wasn't able to reproduce
                    # the issue when I saw it in an experiment with unit
                    # testing???
                    logging.error("unexpected index cleaning up : %s", text)
    out_string = ""
    for line in buffer:
        # knowingly using a for loop instead of a join as adding \n
        out_string += f"{line}\n"  # NOQA

    return out_string


def valid_yaml_string(text: str) -> bool:
    """Validates a string is valid YAML or not

    Args:
        text (str): The string to inspect

    Returns:
        bool: T: valid YAML
    """
    try:
        _ = yaml.safe_load(text)
        return True
    except Exception as e:  # noqa
        if DEBUG:
            print(e)
        return False


def clean_yaml_string_then_validate(text: str) -> bool:
    """Cleans and then validates the cleaned string is YAML.

    Args:
        text (str): The candidate text

    Returns:
        bool: T: valid YAML post cleanup
    """
    cleaned_text = cleanup_yaml_string(text)
    return valid_yaml_string(cleaned_text)


# ----------------------------------------------------------------------
# JSON
# ----------------------------------------------------------------------

def get_json_examples(text: str) -> list:
    """This function is useful for when a LLM may or may not properly
    generate JSON. This can be especially true when the model includes
    incorrect delimiters, etc betwen entities created. This function
    will attempt to parse the results into candidate JSON to be
    parsed by the calling object.

    Args:
        text (str): The text with suspected JSON in it

    Returns:
        list: a series of strings where each contains a candidate
    """
    found_json = []
    if "{" in text:
        idx_start = text.index("{")
        subset_text = text[idx_start:]

        if "}" in text:
            candidate_end = subset_text.index("}") + 1
            second_candidate = subset_text[:candidate_end]
            if second_candidate.count("{") > 1:
                print("MORE?")
                found_json += get_json_examples(second_candidate)
            else:
                found_json.append(second_candidate)
                # and is there more?
                more_text = text[candidate_end:]
                print(f"AX: {more_text}")
                if len(more_text) > 1:
                    found_json += get_json_examples(more_text)
    else:
        return found_json

    return found_json

# ---------------------------------------------------------------------
# Number processing
# ---------------------------------------------------------------------


def is_float(text: str) -> bool:
    """The text represents a float

    Args:
        text (str): candidate text

    Returns:
        bool: T: Float
    """
    if isinstance(text, numbers.Number):
        return True
    if isinstance(text, float):
        return True
    try:
        _ = float(text)
        return True
    except ValueError:
        return False


def is_int(text: str) -> bool:
    """The text represents an int.

    Args:
        text (str): candidate text

    Returns:
        bool: T: int
    """
    if isinstance(text, int):
        return True
    elif isinstance(text, float):
        return True

    if isinstance(text, str):
        if "." in text:
            return False
        try:
            _ = int(text)
            return True
        except ValueError:
            return False


def convert_numbers(record: dict) -> dict:
    """Converts numbers (that are strings) in a record to a number.
    This function uses the is_float, is_int to inform whether to convert
    as int or float.

    Args:
        record (dict): the record to update

    Returns:
        dict: the updated record
    """
    for key, item in record.items():
        if is_int(item):
            record[key] = int(item)
        elif is_float(item):
            record[key] = float(item)
    return record


# ----------------------------------------------------------------------
# Older functions here. need to clean up and remove unused
# ----------------------------------------------------------------------


def convert_str_to_list(input_string: str):
    """converts a string representation of a list into an actual list.
    For exmple str of `["test", "second"]` turns into ["test", "second"]

    Args:
        input_string (str): The candidate string

    Raises:
        Exception: Not a valid input type

    Returns:
        TypeError: Invalid type
    """
    # Safety check
    if isinstance(input_string, str):
        pass
    elif input_string is None:
        return []
    elif isinstance(input_string, list):
        return input_string
    else:
        msg = f"Invalid input for convert_str_to_list: {type(input_string)}"
        raise TypeError(msg)

    input_string = input_string.replace('[', "")
    input_string = input_string.replace(']', "")
    input_string = input_string.replace(' ', "")
    input_string = input_string.replace('"', "")
    input_string = input_string.replace("\n", "")

    # to avoid processing failures
    if len(input_string) == 0:
        return []

    words = input_string.split(',')
    new_list: List[str] = []
    if len(words) == 1 and words[0] == '':
        return new_list
    else:
        for x in words:
            # handling quotes
            if x == '"' or x == "'":
                new_list.append(x)
            else:
                if len(x) > 0:
                    if x[0] == "'":
                        x = x[1:]
                    if x[-1:] == "'":
                        x = x[:-1]
                    if x[0] == '"':
                        x = x[1:]
                    if x[-1:] == '"':
                        x = x[:-1]
                    # and eliminate spaces if any
                    if x[0] == " ":
                        x = x[1:]
                    if x[-1:] == " ":
                        x = x[:-1]

                new_list.append(x)

    return new_list


def prefix_dict(record: dict, prefix: str) -> dict:
    """Prefix a dict keys. For example, adding LEFT_ to every key.

    Args:
        record (dict): The data structure to update
        prefix (str): the prefix to add to every key

    Returns:
        dict: the new data structure
    """
    new_dict = {}
    for key, item in record.items():
        new_dict[f'{prefix}{key}'] = item
    return new_dict


def merge_dict(left: dict, right: dict) -> dict:
    """Merges two dictionaries into a new dict.

    Args:
        left (dict): the first dict
        right (dict): the second dict.

    Returns:
        dict: _description_
    """
    new_dict = left.copy()
    new_dict.update(right)
    return new_dict


def split_left_right(json_text: Union[str, dict]) -> tuple:
    """Splits data into a left and right dict based on the prefix of
    left_ and right_.

    Args:
        json_text (Union[str, dict]): The source data

    Returns:
        tuple: the 2 dict 
    """
    if isinstance(json_text, str):
        try:
            data = json.loads(json_text)
        except Exception as e:
            msg = f"Unable to parse JSON: {e}"
            # Consider the different exceptions or remove this function.
            raise Exception(msg) from e

    else:
        data = json_text

    left_dict = {}
    right_dict = {}
    for key, value in data.items():
        if key.startswith("left_"):
            key = key.replace("left_", "")
            left_dict[key] = value
        elif key.startswith("right_"):
            key = key.replace("right_", "")
            right_dict[key] = value
        elif DEBUG:
            print(f"Ignoring key: {key}")

    left_str = json.dumps(left_dict)
    right_str = json.dumps(right_dict)
    return left_str, right_str


def convert_json_values_to_string(
    records: Union[list, str],
    add_period: bool = True
) -> str:
    """Converts JSON values into a string. It does not include the key
    in the generated text. This can be useful for measuring values.

    Args:
        records (Union[list, str]): The source data
        add_period (bool, optional): add a period after each value?
            Defaults to True.

    Returns:
        str: the merged values as a single string
    """
    sample = ""

    # convert if string
    if isinstance(records, str):
        records = [records]  # so we can re-use logic

    # iterate through records
    for record in records:
        try:
            data = json.loads(record)
        except Exception as e:  # NOQA
            print(e)
            data = {}

        # and iterate through the values.
        for _, value in data.items():
            if isinstance(value, str):
                value = value.replace('"', '')
                sample += value
                if add_period:
                    sample += "."

        # just in case we added an extra
        sample = sample.replace("..", ".")

    return sample


# ----------------------------------------------------------------------
# cleanup methods
# ----------------------------------------------------------------------

def cleanup(text: str) -> str:
    """Initial cleanup function. Used in functions such as drop random

    Args:
        text (str): The text to cleanup

    Returns:
        str: Cleaned up text
    """
    # Perform common cleanups
    text = text.replace("\\n", " ")
    text = text.replace('\\"', '')
    text = text.rstrip()
    text = text.lstrip()

    # replace extra white spaces with a single white space
    split_out = text.split()
    merged = " ".join(split_out)

    r = re.compile(r"\n^\s*", re.MULTILINE)
    return r.sub("", merged)


def cleanup_json_reword(text: str) -> str:
    """Cleans up JSOM strings. These are typically generated by a team.
    Args:
        text (str): the text to cleanup

    Returns:
        str: the cleaned up text
    """
    text = text.replace("\\n", " ")
    text = text.replace("  ", " ")
    text = text.rstrip()
    text = text.lstrip()
    return text.replace('\\"', '')
