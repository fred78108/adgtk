"""Scenario base

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

from adgtk.factory import RequiresAllFactoryEntry, FactoryBlueprint

SCENARIO_GROUP_LABEL = "scenario"


class InvalidScenarioState(Exception):
    """Used for any scenario state that is invalid"""

    default_msg = "Invalid Scenario state."

    def __init__(self, message: str = default_msg):
        super().__init__(message)


class Scenario(RequiresAllFactoryEntry):
    """The Scenario Protocol"""

    blueprint: dict

    def execute(self) -> None:
        """ "Execute actions based on Agent type (interacting with evn,
        expanding data, etc).
        """

    def preview(self) -> None:
        """Builds a preview of the Agent."""


class BaseScenario:
    """Base Scenario. Used for testing and inheritence"""

    blueprint: FactoryBlueprint = {
        "group_label": SCENARIO_GROUP_LABEL,
        "type_label": "base"
    }

    def execute(self) -> None:
        """ "Execute actions based on Agent type (interacting with evn,
        expanding data, etc).
        """

    def preview(self) -> None:
        """Builds a preview of the Agent."""
