"""Scenario Runner

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0 consider moving functions to another file in module
2.0 consider moving default components/blueprints to toml??

Defects:

1.0

Test
py -m pytest -s
"""

__author__ = "Fred Diehl"
__version__ = 0.1

import os
import logging
from typing import Literal, Union
import toml
from adgtk.factory import (
    RequiresAllFactoryEntry,
    SupportsBlueprint,
    ObjectFactory,
    DuplicateFactoryRegistration,
    BlueprintFactory)
from adgtk.journals import ExperimentJournal
from .base import (
    Scenario,
    SCENARIO_GROUP_LABEL,
    InvalidScenarioState)

# ----------------------------------------------------------------------
# Module configs
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
# Functions
# ----------------------------------------------------------------------


def save_blueprint_to_file(
    blueprint: dict,
    filename: str,
    blueprint_dir: str,
    format: Literal["toml", "yaml"]
) -> None:
    """Formats and saves the blueprint to disk.

    Args:
        blueprint (dict): The blueprint
        blueprint_dir (str): The folder to save blueprint to
        filename (str): The file to save. if no extension given it will
            add the appropriate extension, ex: file.yaml or file.toml
        format (Literal["toml","yaml"]): The format

    Raises:
        NotImplementedError: TODO Dev
    """
    # ensure folder exists
    os.makedirs(name=blueprint_dir, exist_ok=True)

    # format the output
    if format == "toml":
        data = toml.dumps(blueprint)
        if not filename.lower().endswith(".toml"):
            file_w_ext = f"{filename}.toml"
        else:
            file_w_ext = filename
    elif format == "yaml":
        raise NotImplementedError

        data = None
        if not filename.lower().endswith(".yaml"):
            file_w_ext = f"{filename}.yaml"
        else:
            file_w_ext = filename
    else:
        raise NotImplementedError("TODO: use the setting default!")

    # save to disk
    file_w_path = os.path.join(blueprint_dir, file_w_ext)

    with open(file_w_path, "w", encoding="utf-8") as outfile:
        outfile.write(data)


def load_experiment_from_file(file_w_path: str) -> dict:
    """Loads an experiment definition from disk

    Args:
        file_w_path (str): The file containing the definition

    Raises:
        NotImplementedError: More work needed here
        FileNotFoundError: Unable to load the file

    Returns:
        dict: The settings for the experiment
    """

    current_directory = os.getcwd()
    print(f"Current Directory: {current_directory}")

    if os.path.exists(os.path.join(".", file_w_path)):
        with open(file_w_path, "r", encoding="utf-8") as infile:
            return toml.load(infile)
    elif os.path.exists(file_w_path):
        raise NotImplementedError("DEV needed")
    else:
        raise FileNotFoundError(
            f"Unable to find experiment definition: {file_w_path}")


# ----------------------------------------------------------------------
# Management : running experiments and creating blueprints
# ----------------------------------------------------------------------

class ScenarioManager:

    def __init__(
        self,
        blueprint_dir: str = "blueprints",
        data_dir: str = "data",
        log_dir: str = "logs",
        results_dir: str = "results",
        tensorboard_dir: str = "runs",
        experiment_definition_dir: str = "experiment-definition",
        load_base: bool = True
    ) -> None:
        self.blueprint_dir = blueprint_dir
        self.experiment_definition_dir = experiment_definition_dir
        self.active_scenario: Union[Scenario, None] = None

        # setup internal objects
        self._journal = ExperimentJournal(experiment_name="TODO.journal")
        self._factory = ObjectFactory(journal=self._journal)
        self._blueprints = BlueprintFactory()

        # load objects :TODO fix specs
        # self._load_base_components()

    def _load_base_blueprints(self) -> None:
        self._blueprints.register(
            group_label="agent",
            type_label="agent",
        )

    def _load_factories(
        self,
        group_label: str,
        type_label: str,
        creator: SupportsBlueprint,
        set_default_blueprint: bool = False
    ) -> None:

        # Load component
        self._factory.register(
            group_label=group_label,
            type_label=type_label,
            creator=creator)

        # load factory
        self._blueprints.register(
            group_label=group_label,
            type_label=type_label,
            blueprint=creator.blueprint,
            set_default_blueprint=set_default_blueprint)

    def _load_base_components(self) -> None:
        """Loads the base components into the factories
        """
        # TODO: call the __init__ register_all functions
        pass

    def load_experiment(self, experiment_name: str) -> None:
        file_w_path = os.path.join(
            self.experiment_definition_dir, experiment_name)
        exp_def = load_experiment_from_file(file_w_path)
        self.active_scenario = self._factory.create(exp_def)

    def preview_experiment(self) -> None:
        if self.active_scenario is not None:
            self.active_scenario.preview()
        else:
            msg = "No loaded scenario to preview"
            logging.error(msg)
            raise InvalidScenarioState(msg)

    def run_experiment(self) -> None:
        if self.active_scenario is not None:
            self.active_scenario.execute()
        else:
            msg = "No loaded scenario to run"
            logging.error(msg)
            raise InvalidScenarioState(msg)

    def build_blueprint(
        self,
        type_label: str,
        group_label: str = SCENARIO_GROUP_LABEL
    ) -> None:
        """Triggers a save to disk for a blueprint

        Args:
            type_label (str): The type
            group_label (str, optional): The group.
                Defaults to  SCENARIO_GROUP_LABEL.
        """
        blueprint = self._blueprints.create(
            group_label=group_label,
            type_label=type_label)

        save_blueprint_to_file(
            blueprint=blueprint,
            blueprint_dir=self.blueprint_dir,
            format="toml",
            filename=f"{group_label}.{type_label}")

    def register(
        self,
        creator: SupportsBlueprint,
        override_group_label: Union[str, None] = None,
        override_type_label: Union[str, None] = None,
        set_default_blueprint: bool = False
    ) -> None:
        """_summary_

        Args:
            creator (SupportsBlueprint): The component to build
            override_group_label (Union[str, None], optional): Override
                the group label. Defaults to None.
            override_type_label (Union[str, None], optional): Override
                the type label. Defaults to None.
            set_default_blueprint (bool, optional): Use the blueprint as
                the default for this group. Defaults to False.
        """

        # load from component if not over
        if override_group_label is None:
            group_label = creator.blueprint["group_label"]
        else:
            group_label = override_group_label

        if override_type_label is None:
            type_label = creator.blueprint["type_label"]
        else:
            type_label = override_group_label

        try:
            self._load_factories(
                group_label=group_label,
                type_label=type_label,
                creator=creator,
                set_default_blueprint=set_default_blueprint)
        except DuplicateFactoryRegistration:
            err_msg = "Duplicate Registration attempted for "\
                f"{group_label}.{type_label}"

            logging.error(err_msg)
