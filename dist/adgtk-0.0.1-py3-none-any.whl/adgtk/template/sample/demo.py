"""Used to demonstrate a typical extension for ADGTK
"""


class TestClassOne:
    """An extremely basic class for demonstrating settings.py"""

    def __init__(self):
        self.counter = 0

    def hello(self):
        """Print something to console
        """
        print("Hello World")

    def greeting(self):
        """Print something to console
        """
        print("Greetings from the demo code")
