# Agentic Data Generation Toolkit


## Useful references
Move to my notes later!
- https://packaging.python.org/en/latest/guides/creating-and-discovering-plugins/
- https://packaging.python.org/en/latest/flow/
- https://choosealicense.com/
- https://docs.python.org/3/reference/import.html
- https://packaging.python.org/en/latest/guides/creating-command-line-tools/
- https://packaging.python.org/en/latest/guides/writing-pyproject-toml/
- 
## Explore
- https://typer.tiangolo.com/#run-it
- https://pypi.org/project/cookiecutter-cc/

# Read later
- https://packaging.python.org/en/latest/specifications/entry-points/#entry-points

## Ideas

- wizard script that interviews and builds a blueprint?
  - invokes an object method.
  - centralized inventory of registered objects
  - use a toml file to update catalog?? avoid having to load all??? try!
- add a method that constructs a blueprint for each object type?
- add a loader to each module/class??? 


## Installation

```shell
$ python -m pip install ml-agent-x
```

# TODO
Figure out to automate in the pipeline the following command:
```
tar --exclude="*.pyc" --exclude="*__pycache" -cvf template.tar template/ 
```