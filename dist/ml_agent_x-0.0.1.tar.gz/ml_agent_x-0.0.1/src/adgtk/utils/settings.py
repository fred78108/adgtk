"""Summary goes here.

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0

Test
python -m unittest tests.
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

import toml


# ----------------------------------------------------------------------
# Module configuration
# ----------------------------------------------------------------------
SETTINGS_FILE = "settings.toml"

# ----------------------------------------------------------------------
#
# ----------------------------------------------------------------------


def load_settings() -> dict:
    """Loads the settings file

    Returns:
        dict: settings
    """
    with open(SETTINGS_FILE, "r", encoding="utf-8") as infile:
        return toml.load(infile)
