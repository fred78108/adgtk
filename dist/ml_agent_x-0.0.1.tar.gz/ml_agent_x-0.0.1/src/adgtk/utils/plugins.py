"""Summary goes here.

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0

Test
python -m unittest tests.
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


import importlib
import pkgutil
import adgtk.plugins

# ----------------------------------------------------------------------
# Module configuration
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
#
# ----------------------------------------------------------------------
def load_plugins():
    plugins_to_load = pkgutil.iter_modules(
        plugins.__path__, adgtk.plugins.__name__ + ".")

    for _, name, _ in plugins_to_load:
        print(f"loading {name}")
        importlib.import_module(name)
