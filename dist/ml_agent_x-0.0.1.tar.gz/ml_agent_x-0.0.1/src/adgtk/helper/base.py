"""does it work?"""


def hello():
    """A simple test"""
    print("It works!")
