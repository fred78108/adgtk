import shutil

shutil.make_archive("template", "tar", "template")
