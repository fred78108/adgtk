"""Scenarios

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


import scenario.factory as scenario_factory
from .measure import MeasureModelPerformanceScenario, MeasureDatasetScenario
from .base import Scenario

# ----------------------------------------------------------------------
# built-in scenarios
# ----------------------------------------------------------------------
scenario_factory.register("measure-dataset-scenario", MeasureDatasetScenario)
scenario_factory.register(
    "measure-model-performance-scenario", MeasureModelPerformanceScenario
)
