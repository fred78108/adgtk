"""Included Measurement scenarios

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

from typing import Mapping
import toml


class MeasureModelPerformanceScenario:

    # TODO: start back here!
    blueprint = {
        "registered_as": "measure-model-performance-scenario",
        "model_ckpt": "set_model_ckpt_here",
        "agent": "default",
    }

    def __init__(self, model_ckpt: str, dataset: str) -> None:
        pass

    def execute(self) -> None:
        """ "Execute actions based on Agent type (interacting with evn,
        expanding data, etc).
        """
        print("execute - measure model")

    def preview(self) -> None:
        """Builds a preview of the Agent."""
        print("preview - measure model")


class MeasureDatasetScenario:
    def __init__(self) -> None:
        pass

    def execute(self) -> None:
        """ "Execute actions based on Agent type (interacting with evn,
        expanding data, etc).
        """
        print("execute - measure DS")

    def preview(self) -> None:
        """Builds a preview of the Agent."""
        print("preview - measure DS")
