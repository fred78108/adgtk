"""Environment base

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


from typing import Protocol
from common import Action, State


class Environment(Protocol):
    """The Environment Protocol"""

    blueprint: dict

    def action_space(self) -> list[Action]:
        """Gets a list of acceptable actions

        Returns:
            list[Action]: The acceptable actions
        """

    def reset(self, value: int = 0) -> State:
        """Resets the state

        Args:
            value (int, optional): The state index. Defaults to 0.

        Returns:
            State: The new state
        """

    def step(self, action: Action) -> tuple[State, bool]:
        """Take an action on the Environment

        Args:
            value (int, optional): _description_. Defaults to 0.

        Returns:
            tuple[State, bool]: the new state and rollover?
        """
