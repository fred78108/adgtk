"""Exceptions used across the application

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0

Test
N/A
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


# ----------------------------------------------------------------------
# Module configuration
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
#
# ----------------------------------------------------------------------


class DuplicateFactoryRegistration(Exception):
    """Used for registration collision"""

    default_msg = "Registration exists. Unregister first."

    def __init__(self, message: str = default_msg):
        super().__init__(message)
