from .base import PluginDefinition
