"""Welcome to ADGTK (Agentic Data Generation Tool Kit). 

This is a pre-release development version of the project.
"""


__version__ = "0.1.0a1"

__author__ = "Fred Diehl"

__maintainer__ = "Fred Diehl"

from .common import ArgumentSetting, ArgumentType, FactoryBlueprint