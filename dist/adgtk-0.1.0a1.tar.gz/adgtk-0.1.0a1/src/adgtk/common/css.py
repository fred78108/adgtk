"""Common CSS tags for different objects. Useful for applying future CSS
"""

MEAS_HEADER_CSS_TAG = "measurement-header"
MEAS_DIV = "measurement-div"
