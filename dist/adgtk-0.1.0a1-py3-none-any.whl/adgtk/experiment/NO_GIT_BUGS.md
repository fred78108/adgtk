
# Bug list

## UX
- anytree on experiment preview post configuration is no longer showing the full tree.