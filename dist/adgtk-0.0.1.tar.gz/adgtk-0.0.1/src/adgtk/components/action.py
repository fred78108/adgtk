"""State details. The idea with using a protocol is to give the greatest
level of flexibility by enabling plugins to implement different state
types and remaining consistent across the Agent, Policy, etc interfaces.

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

from typing import Protocol


class Action(Protocol):
    type: str
