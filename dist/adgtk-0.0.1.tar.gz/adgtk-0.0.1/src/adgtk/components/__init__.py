"""common components"""
from .action import Action
from .state import State
from .agent import BaseAgent, BasicAgent
from .environment import BasicEnvironment
from .policy import RandomPolicy
from adgtk.scenario import ScenarioManager


def register_builtins(scenario_manager: ScenarioManager) -> None:
    """Registers the built-in Components into the Users ScenarioManager.

    :param scenario_manager: The ScenarioManager to load the 
        built-in components to
    :type scenario_manager: ScenarioManager
    """
    scenario_manager.register(
        component=BasicAgent, set_default_blueprint=True)
    scenario_manager.register(
        component=RandomPolicy, set_default_blueprint=True)
    scenario_manager.register(
        component=BasicEnvironment, set_default_blueprint=True)
