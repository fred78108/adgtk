"""_summary_
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


from adgtk.factory import FactoryBlueprint
from adgtk.components import Action, State


class BasicEnvironment:
    """The Basic Environment for testing and inheritence"""

    blueprint: FactoryBlueprint = {
        "group_label": "environment",
        "type_label": "basic",
        "arguments": {}
    }

    def __init__(self):
        pass

    def action_space(self) -> list[Action]:
        """Gets a list of acceptable actions

        Returns:
            list[Action]: The acceptable actions
        """
        return []

    def reset(self, value: int = 0) -> State:
        """Resets the state

        Args:
            value (int, optional): The state index. Defaults to 0.

        Returns:
            State: The new state
        """
        return State()

    def step(self, action: Action) -> tuple[State, bool]:
        """Take an action on the Environment

        Args:
            value (int, optional): _description_. Defaults to 0.

        Returns:
            tuple[State, bool]: the new state and rollover?
        """
        return (State(), False)
