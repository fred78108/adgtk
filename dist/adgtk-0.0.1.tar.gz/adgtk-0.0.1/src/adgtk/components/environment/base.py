"""Environment base
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


from typing import Protocol
from adgtk.components import Action, State
from adgtk.factory import FactoryBlueprint


class Environment(Protocol):
    """The Environment Protocol"""

    blueprint: FactoryBlueprint

    def action_space(self) -> list[Action]:
        """Gets a list of acceptable actions

        Returns:
            list[Action]: The acceptable actions
        """

    def reset(self, value: int = 0) -> State:
        """Resets the state

        Args:
            value (int, optional): The state index. Defaults to 0.

        Returns:
            State: The new state
        """

    def step(self, action: Action) -> tuple[State, bool]:
        """Take an action on the Environment

        Args:
            value (int, optional): _description_. Defaults to 0.

        Returns:
            tuple[State, bool]: the new state and rollover?
        """

# TODO: totally rethink this base class!


class BaseEnvironment:
    """The Base Environment for testing and inheritence"""

    blueprint: FactoryBlueprint = {
        "group_label": "environment",
        "type_label": "base",
        "arguments": {}
    }

    def action_space(self) -> list[Action]:
        """Gets a list of acceptable actions

        Returns:
            list[Action]: The acceptable actions
        """
        return []

    def reset(self, value: int = 0) -> State:
        """Resets the state

        Args:
            value (int, optional): The state index. Defaults to 0.

        Returns:
            State: The new state
        """
        return State()

    def step(self, action: Action) -> tuple[State, bool]:
        """Take an action on the Environment

        Args:
            value (int, optional): _description_. Defaults to 0.

        Returns:
            tuple[State, bool]: the new state and rollover?
        """
        return (State(), False)
