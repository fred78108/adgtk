"""Agent base provides the foundational components for the module.
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

from typing import Protocol
from adgtk.factory import FactoryBlueprint
from adgtk.components import State, Action
from adgtk.components.environment import Environment


class Agent(Protocol):
    """The Agent Protocol"""

    blueprint: FactoryBlueprint

    def execute(self) -> None:
        """ "Execute actions based on Agent type (interacting with env,
        expanding data, etc).
        """

    def preview(self) -> None:
        """Builds a preview of the Agent."""

    def engage(self, state: State) -> Action:
        """Engages the Agent for a single record.

        Args:
            state (State): The state to execute the policy against

        Returns:
            Action: The action to take
        """

    def train(
        self,
        train_environment: Environment,
        val_environment: Environment = None,
        test_environment: Environment = None,
        epochs: int = 1,
    ) -> None:
        """Explores an environment and trains the provided policy to
        learn how to predict match versus non-match for the entities.

        :param train_environment: The env for training
        :type train_environment: Environment
        :param val_environment: validation env
        :type val_environment: Environment, optional
        :param test_environment: The test env
        :type test_environment: Environment, optional
        :param epochs:  outer epochs, for the agent not the policy
        :type epochs: int, optional
        """

# ---------------------------------------------------------------------
# base Agent that can be used for inheritence, testing, etc
# ---------------------------------------------------------------------


class BaseAgent:
    """Provides an initial Agent that can be used in a project to
    inherit from. It is not required you inherit from the Class only
    that you implement the Agent Protocol."""

    blueprint: FactoryBlueprint = {
        "group_label": "environment",
        "type_label": "base",
        "arguments": {}
    }

    def __init__(self, **kwargs) -> None:
        pass
        # tester = config.tester
        # print(f"Tester = {tester}")

    def execute(self) -> None:
        """ "Execute actions based on Agent type (interacting with env,
        expanding data, etc).
        """
        pass

    def preview(self) -> None:
        """Builds a preview of the Agent."""
        pass

    def engage(self, state: State) -> Action:
        """Engages the Agent for a single record.

        Args:
            state (State): The state to execute the policy against

        Returns:
            Action: The action to take
        """
        pass

    def train(
        self,
        train_environment: Environment,
        val_environment: Environment = None,
        test_environment: Environment = None,
        epochs: int = 1,
    ) -> None:
        """Explores an environment and trains the provided policy to
        learn how to predict match versus non-match for the entities.

        :param train_environment: The env for training
        :type train_environment: Environment
        :param val_environment: validation env
        :type val_environment: Environment, optional
        :param test_environment: The test env
        :type test_environment: Environment, optional
        :param epochs:  outer epochs, for the agent not the policy
        :type epochs: int, optional
        """
        pass
