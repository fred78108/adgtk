"""Simple built-in Agent to use directly or inherit from.
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

from adgtk.factory import FactoryBlueprint, EXPAND_USING_DEFAULT
from adgtk.components import State, Action
from adgtk.components.environment import Environment


class BasicAgent:

    blueprint: FactoryBlueprint = {
        "group_label": "agent",
        "type_label": "basic",
        "arguments": {
            "policy": {
                "group_label": "policy",
                "type_label": EXPAND_USING_DEFAULT
            }
        }
    }

    def __init__(self, **kwargs) -> None:
        pass
        # tester = config.tester
        # print(f"Tester = {tester}")

    def execute(self) -> None:
        """ "Execute actions based on Agent type (interacting with env,
        expanding data, etc).
        """
        pass

    def preview(self) -> None:
        """Builds a preview of the Agent."""
        pass

    def engage(self, state: State) -> Action:
        """Engages the Agent for a single record.

        Args:
            state (State): The state to execute the policy against

        Returns:
            Action: The action to take
        """
        pass

    def train(
        self,
        train_environment: Environment,
        val_environment: Environment = None,
        test_environment: Environment = None,
        epochs: int = 1,
    ) -> None:
        """Explores an environment and trains the provided policy to
        learn how to predict match versus non-match for the entities.

        :param train_environment: The env for training
        :type train_environment: Environment
        :param val_environment: validation env
        :type val_environment: Environment, optional
        :param test_environment: The test env
        :type test_environment: Environment, optional
        :param epochs:  outer epochs, for the agent not the policy
        :type epochs: int, optional
        """
        pass
