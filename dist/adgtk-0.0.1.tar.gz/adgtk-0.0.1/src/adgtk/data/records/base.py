"""Base Records
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


from typing import Protocol, Union, Callable, TypeVar, Any
from adgtk.factory import PresentationFormat

# py -m pytest -s test/folder/.py

# ----------------------------------------------------------------------
# Types and Protocols
# ----------------------------------------------------------------------

T = TypeVar("T", bound=Callable, covariant=True)


class PresentableRecord(Protocol):

    def __init__(
        self,
        presentation: PresentationFormat,
        data: Union[tuple, None],
        use_cached_str: bool,
        **args
    ):
        pass

    def __str__(self) -> str:
        """Generates a string representation

        :return: A string representation of the Record 
        :rtype: str
        """


class DataRecord:

    def __init__(
        self,
        presentation: PresentationFormat,
        data: dict[str, Any],
        use_cached_str: bool = True,
        metadata: Union[dict[str, Any], None] = None,
        ** args
    ):
        """A Data record is a base Class for the internal data storage

        :param presentation: The presentation 
        :type presentation: PresentationFormat
        :param data: the data for the record
        :type data: dict
        :param use_cached_str: generate str once, defaults to True
        :type use_cached_str: bool, optional
        :param metadata: metadata for the record, defaults to None
        :type metadata: Union[dict, None]
        """
        self.use_cached_str = use_cached_str
        self.presentation = presentation
        self.data = data
        if use_cached_str:
            self._string_rep_cached = self.presentation.present(self.data)

        if metadata is None:
            self.metadata = {}
        else:
            self.metadata = metadata

    def __str__(self) -> str:
        """Presents the string representation using the cached

        :return: String representation of the data
        :rtype: str
        """
        if self.use_cached_str:
            return self._string_rep_cached

        return self.presentation.present(self.data)

    def create_copy_of_data(self) -> dict:
        return self.data.copy()

    def get_data_keys(self) -> list:

        # to protect against caller modifing the list.
        tmp_data = self.create_copy_of_data()
        return list(tmp_data.keys())
