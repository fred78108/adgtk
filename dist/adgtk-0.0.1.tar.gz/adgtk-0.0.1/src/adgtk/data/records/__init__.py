"""data records
"""

from .base import DataRecord, PresentableRecord
