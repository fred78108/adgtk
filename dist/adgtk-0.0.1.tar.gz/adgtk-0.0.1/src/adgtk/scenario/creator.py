"""Used for creating scenarios

Versions:
v 0.1
- mvp

References:
-

TODO:

1.0

Defects:

1.0

Test
py -m pytest -s
"""

__version__ = "0.1"
__author__ = "Fred Diehl"

import os
import logging
from typing import Literal
import toml
import yaml
from adgtk.utils import load_settings

# ----------------------------------------------------------------------
# Module configuration
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
#
# ----------------------------------------------------------------------
