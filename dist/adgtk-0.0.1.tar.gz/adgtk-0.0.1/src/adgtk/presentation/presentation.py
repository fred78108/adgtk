"""Presentation of a Record
"""

__version__ = "0.1"
__author__ = "Fred Diehl"


import logging

# ----------------------------------------------------------------------
#
# ----------------------------------------------------------------------
# py -m pytest -s test/folder/.py
